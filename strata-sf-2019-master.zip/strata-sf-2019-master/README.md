# strata-sf-2019
Strata SF 2019 training: Expand your data science and machine learning skills with Python, R, SQL, Spark, and TensorFlow

Slides: https://goo.gl/ogMzPj
